<?php 

$host="localhost";
$id="root1";
$pass="";
$db="bmw";
$conn = mysqli_connect($host,$id,$pass,$db);


?>