<?php 

$host="localhost";
$id="root";
$pass="";
$db="bmw";
$conn = mysqli_connect($host,$id,$pass,$db);


?>