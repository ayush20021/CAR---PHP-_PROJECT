<?php 

echo"<div class='container'>
<footer class='d-flex align-items-center mt-5 ab'>
  <div class='container-fluid footerC mt-5'>
    <div class='row mb-1 justify-content-center'>
      <div
        class='col'
      >
        <h3>CONTACT</h3>
        <div>Find a Dealer</div>
        <div>Request a Test Drive</div>
        <div>Careers</div>
        <div>Contact Us</div>
      </div>
      <div
        class='col'
      >
        <h3>QUICK LINKS</h3>
        <div>Build your BMW</div>
        <div>BMW Financial Services</div>
        <div>EMI Calculator</div>
        <div>BMW Premium Selection (Used Cars)</div>
      </div>
      <div
        class='col'
      >
        <h3>EXPERIENCE BMW</h3>
        <div>BMW Group</div>
        <div>BMW Excellence Club</div>
        <div>Awards and Recognition</div>
        <div>BMW Motorrad</div>
      </div>
      <div
        class='col'
      >
        <h3>LEGAL</h3>
        <div>Legal Disclaimer/Imprint</div>
        <div>Privacy Policy</div>
      </div>
    </div>
  </div>
  
</footer>
</div>";


?>